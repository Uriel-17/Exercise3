package edu.sjsu.android.intentapp;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoaderActivity extends Activity {
//    private Button web;
//    private Button call;
//
//    @Override public void onCreate(Bundle savedInstanceState) {
//
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activityloaderactivity);
//
//        web = (Button) findViewById(R.id.webBrowser);
//        call = (Button) findViewById(R.id.makeCalls);
//
//
//
//    }
//
//
//    public void onWebBrowserClick(View view) {
////        Uri webpage = Uri.parse("http://www.amazon.com");
//        String URL = "http://www.amazon.com";
//        Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(URL));
//        webIntent.putExtra("content", URL);
//
//        Intent chooser = Intent.createChooser(webIntent, "test");
//
//
//        startActivity(chooser);
//
//    }
//
//    public void onMakeCallsClick(View view) {
//
//        String myPhoneNumberUri = "tel:+194912344444";
//        Intent myActivity2 = new Intent(Intent.ACTION_DIAL, Uri.parse(myPhoneNumberUri));
//        startActivity(myActivity2);
//
//    }
//


}
