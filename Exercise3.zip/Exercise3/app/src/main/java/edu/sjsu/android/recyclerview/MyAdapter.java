package edu.sjsu.android.recyclerview;
import java.util.ArrayList;
import java.util.List;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import edu.sjsu.android.exercise3.R;


public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {
    private List<String> values;

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder public class ViewHolder extends RecyclerView.ViewHolder {
    // each data item is just a string in this case
   public class ViewHolder extends RecyclerView.ViewHolder {
       // each data item is just a string in this case
        public TextView txtHeader;
        public TextView txtFooter;
        public View layout;

        public ViewHolder(View v) {
            super(v);
            layout = v;
            txtHeader = (TextView) v.findViewById(R.id.firstLine);
            txtFooter = (TextView) v.findViewById(R.id.secondLine);

        }
    }

    public void add(int position, String item) {
       values.add(position, item);
       notifyItemInserted(position);
    }

    public void remove(int position) {
       values.remove(position);
       notifyItemRemoved(position);
    }

    public MyAdapter(List<String> myDataset) {
       values = myDataset;
    }

    @Override public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       LayoutInflater inflater = LayoutInflater.from(parent.getContext());

       View v = inflater.inflate(R.layout.row_layout, parent, false);

       ViewHolder vh = new ViewHolder(v);

       return vh;
    }

    @Override public void onBindViewHolder(ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
       final String name = values.get(position);
       holder.txtHeader.setText(name);
       holder.txtHeader.setOnClickListener(new OnClickListener() {
           @Override
           public void onClick(View view) {
               remove(position);
           }
       });
       holder.txtFooter.setText("Footer: " + name);
    }

    @Override public int getItemCount() {
       return values.size();
    }


}